package # hide from pause
  SQL::Translator::Schema::Graph::Port;

use strict;
use warnings;

1;
